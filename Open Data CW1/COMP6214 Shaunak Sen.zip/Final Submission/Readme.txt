File to run - index.html

Clean dataset used for the vizualization: Clean_data_final.csv

Please run the index.html file through a local web server so that the files are correctly loaded

